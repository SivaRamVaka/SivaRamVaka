﻿using Microsoft.EntityFrameworkCore;

namespace SampleServiceApplication.Models
{
    public class StudentDBContext : DbContext
    {
        public StudentDBContext()
        {

        }

        public StudentDBContext(DbContextOptions<StudentDBContext> options) : base(options)
        {

        }

        public DbSet<Student> Students { get; set; }
    }
}
