﻿using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
namespace SampleServiceApplication.Models
{
    public class StudentAcess
    {
        //StudentDBContext dbContext = new StudentDBContext();
        //public List<Student> AddStudents(Student obj)
        //{
        //    List<Student> students = dbContext.Students.Add(obj); 


        //}
    }
}
