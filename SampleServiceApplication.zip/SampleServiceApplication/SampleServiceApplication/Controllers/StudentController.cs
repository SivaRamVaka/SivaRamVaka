﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections;
using System.Collections.Generic;
using SampleServiceApplication.Models;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

namespace SampleServiceApplication.Controllers
{
    [Route("api/student")]
    [ApiController]
    public class StudentController : ControllerBase
    {
     //   StudentDBContext context;

        public StudentController (StudentDBContext conf)
        {
            context = conf;
        }

        StudentDBContext context = new StudentDBContext();
        [HttpGet]
        [Route("Addstudent")]
        public ActionResult Addstudent(Student stu)
        {
           
           
            context.Students.Add(stu);
            context.SaveChanges();
            return Ok("Success");


        }

        [HttpGet]
        [Route("Getstudent")]
        public async Task<ActionResult> GetStudents()
        {
           List<Student> students = new List<Student>();
            students =await context.Students.ToListAsync();
            return Ok(students);
        }
    }
}
