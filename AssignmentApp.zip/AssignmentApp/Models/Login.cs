﻿namespace AssignmentApp.Models
{
    public class Login
    {
        public string username { get; set; }
        public string possword { get; set; }
    }
}
