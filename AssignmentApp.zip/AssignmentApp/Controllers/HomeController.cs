﻿using AssignmentApp.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;

namespace AssignmentApp.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {

            if (Request.Cookies["login_status"] != null)
            {
                ViewBag.Status = "LoggedIn";
            }
            else
            {
                ViewBag.Status = "NotLoggedIn";
            }
            return View();
        }
        [HttpPost]
        public ActionResult Login(Login data)
        {
            if (data.username == "abc" && data.possword == "abc")
            {
                CookieOptions opt = new CookieOptions();
                opt.Expires = DateTime.Now.AddYears(1);
                Response.Cookies.Append("login_status", "1", opt);
            }
            return RedirectToAction("Login");
        }

        
        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

    }
}
